
BattleProject - DE10-Lite Quartus Project
Generated: 2025-12-03T19:18:37.172968 UTC

Contents:
- top.v            (top-level wrapper)
- fsm_battle.v     (FSM game implementation)
- bcd7seg.v        (7-seg driver)
- BattleProject.qsf  (pin assignments for DE10-Lite taken from uploaded pin list)  [See filecite below]
- BattleProject.qpf  (simple project file)

Notes:
- This is a ready-to-open Quartus Prime Lite 18.1 project aimed at the DE10-Lite board (10M50).
- The pin assignments match the Terasic DE10-Lite pin list you provided.
- Key usage: KEY[0] = start/confirm, KEY[1] = capture; switch SW[9] = master ON/OFF; SW[0..1] used as 2-bit selector.
- Health display: HEX0/HEX1 -> Player1 (units,tens), HEX2/HEX3 -> Player2, HEX4/HEX5 used for messages.
- You may need to adjust 'WELCOME_CYCLES' or slowclk divider if you want different timing.
- If you want active-low vs active-high segment polarity changed, invert bits in bcd7seg or assignment.

Filecite: Pin mapping was taken from the uploaded Terasic DE10-Lite Pin list document. fileciteturn0file0
